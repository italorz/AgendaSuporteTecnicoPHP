<?php 
require_once('server.php');

$listarusuario=$sql->prepare("SELECT * from usuarios order by nome");
$listarusuario->execute();
$rlistarusuario=$listarusuario->fetchAll(PDO::FETCH_ASSOC);
$clistarusuario=count($rlistarusuario);
if ($clistarusuario==0) {
    echo
    'nenhum registro foi encontrado';
}else{
    for ($i=0; $i < $rlistarusuario; $i++) { 
        foreach ($rlistarusuario[$i] as $key => $value) {}
    
    
    echo<<<HTML
 
    <table data-toggle="table">
      <thead>
        <tr>
          <th>Item ID</th>
          <th>Item Name</th>
          <th>Item Price</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Item 1</td>
          <td>$1</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Item 2</td>
          <td>$2</td>
        </tr>
      </tbody>
    </table>
    HTML;



};
};

?>