<?php
require_once('server.php');
require_once('html/head.php');
require_once('html/header.php');
?>
<!DOCTYPE html>
<html lang="pt-br">

<title>Agenda</title>

<body>
    <div class="container" style="padding-top: 75px;">

        
            <div class="shadow">
                <div class="p-4">
                    <div class="m-2">
                        <div class="text-center">

                            <a href="data.php" type="button" class="btn btn-outline-primary btn-lg fs-4 shadow" style="margin:5%; padding:7%; transition: 1s;">Agendar</a>
                            <button type="button" class="btn btn-outline-primary btn-lg fs-4 shadow" style="margin:5%; padding:7%; transition: 1s;">Ver agendamento</button>
                        </div>
                    </div>
                </div>
        
    </div>
</body>

</html>