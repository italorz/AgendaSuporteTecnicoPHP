<?php
require_once('server.php');
session_start();
// $data = '12/20/2023';
$qassunto = $sql->query("SELECT * from assunto");
$assunto = $qassunto->fetchAll(PDO::FETCH_ASSOC);
@$minuto = $assunto['tempo'];
$_SESSION['minuto'] = $minuto;
@$telefone = $_POST['telefone'];
@$cliente = $_POST['cliente'];
if (isset($_POST['cliente']) == 0) {
    echo  "<script>window.location='data.php'</script>";
}
$dt = $_POST['data'];
$data = date("Y-m-d", strtotime(str_replace("/", "-", $dt)));
$IdTecnico = $_POST['tecnico'];
// select para validar horario disponivel
$query = $sql->prepare("
    SELECT h.hora 
    FROM horario h
    WHERE NOT EXISTS (
        SELECT 1 
        FROM agenda a 
    WHERE 
    DATE(a.dia) = :dia AND 
    a.hora = h.hora AND 
    a.id_tecnico = :id_tecnico 
            
    )and h.id_tecnico = :id_tecnico;
");
$query->bindValue(':dia', $data);
$query->bindValue(':id_tecnico', $IdTecnico);
$query->execute();
$resultados = $query->fetchAll(PDO::FETCH_ASSOC);
$conta = count($resultados);

if ($conta == 0) {
    echo
    '<script>window.alert("Este tecnico esta sem horarios disponivel para esta data. Escolha outra data e ou outro tecnico")</script>';
    echo "<script>window.location='data.php'</script>";
}
$nome = $sql->query("SELECT nome from tecnico where id_tecnico = $IdTecnico");
$ResultadoNome = $nome->fetchAll(PDO::FETCH_ASSOC);
$nome = $ResultadoNome[0]['nome'];

$cadastrocliente = $sql->query("SELECT * from cliente where telefone_cliente = '$telefone'");
$rcadcliente = $cadastrocliente->fetchAll(PDO::FETCH_ASSOC);
$ccadcliente = count($rcadcliente);
if ($ccadcliente == 0) {
    $insertcliente = $sql->query("INSERT into cliente set nome_cliente='$cliente', telefone_cliente='$telefone'");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Tn538Nl4zrL2UxWOdBqLwkHefIG5QDAHOBGLtn8i6T5br5r5zpf0tuw1u31PbbC" crossorigin="anonymous">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <style>
        #formulario {
            padding-right: 15%;
            padding-left: 15%;
            padding-bottom: 3%;
        }

        @media screen and (max-width: 700px) {
            #formulario {
                padding-right: 0;
                padding-left: 0;
                padding-bottom: 0;
            }
        }
    </style>
</head>

<body>


    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top shadow">
            <div class="container-fluid ">
                <a class="navbar-brand" href="#"><button type="button" class="btn btn-primary bg-dark" style="border-color:#212529; font-size: large;"><img src="img/1.png" alt="" style="height: 30px; width: 110px;"></button></a>


                <button class="navbar-toggler btn-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon btn-sm"></span>
                </button>
                <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel" style="transition: 1s;">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Usuario:</h5>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="transition: 1s;">
                                    Cadastro
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" style="transition: 1s;">
                                    <li><a class="dropdown-item" href="#">Usuario</a></li>
                                    <li><a class="dropdown-item" href="#">Servicos</a></li>
                                    <li><a class="dropdown-item" href="#">Categorias</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="container" style="padding-top: 75px;">

        <form id="AjaxFormAgendamento" action="ConcluirAgendamento.php" method="post">
            <div class="shadow" id="formulario">
                <div class="form-group p-4">
                    <div class="d-flex .col-ms-6  m-2">
                        <h6 class="h6 mx-2">Tecnico: <?php echo $nome; ?></h6>
                        <h6 class="h6">Dia: <?php echo $dt; ?></h6>
                    </div>


                    <div class=".col-ms-6  m-2">
                        <small for="">Assunto:</small>
                        <select class="form-control" name="assunto" id="assunto" style="width: 100%; font-size: large;" required>
                            <option type="hidden" required class="form-control" name="assunto" id="assunto" value=""></option>

                            <?php
                            foreach ($assunto as $rassunto) {
                                echo '<option class="form-control" id="assunto" name="assunto" value="' . $rassunto['id_assunto'] . '">'
                                    . $rassunto['nome_assunto'] . ', - <b style="font-weight: bold;">tempo estimado:</b> ' . $rassunto['tempo'] . ' minutos </option>';
                            };
                            ?>





                            ?>
                        </select>
                    </div>
                    <div class=".col-ms-6  m-2">
                        <small>Selecione um horario:</small>
                        <select class="form-control" name="horario" id="horario" style="width: 100%; font-size: large;" required>
                            <option type="hidden" required class="form-control" name="horario" id="horario" value=""></option>

                            <?php
                            foreach ($resultados as $res) {
                                echo
                                '<option class="form-control" id= "horario" name="horario" value="' . $res['hora'] . '">' . $res['hora'] . '</option>';
                            };


                            ?>
                        </select>
                    </div>

                    <div class=".col-ms-6  m-2">
                        <small for="">Observações:</small>
                        <textarea name="observacoes" class="form-control" id="exampleFormControlTextarea1" rows="7" required></textarea>
                    </div>
                    <div class=".col-ms-6  m-2 text-center">
                        <button type="submit" id="AjaxConcluirAgendamento" class="btn btn-primary">Concluir Agendamento</button>
                    </div>
                    <div id="mensagem-cadastro"></div>

                    <input type="hidden" name="telefone" value="<?php echo $telefone; ?>">
                    <input type="hidden" name="cliente" value="<?php echo  $cliente; ?>">
                    <input type="hidden" name="data" value="<?php echo $data; ?>">
                    <input type="hidden" name="nome" value="<?php echo $nome; ?>">
                    <input type="hidden" name="IdTecnico" value="<?php echo $IdTecnico; ?>">
                    <input type="hidden" name="IdCliente" value="<?php echo $IdCliente; ?>">





                </div>
            </div>
        </form>
    </div>

</body>

<?php

?>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<script type="text/javascript">
    $("#AjaxFormAgendamento").submit(function() {
        event.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: "ConcluirAgendamento.php",
            type: 'POST',
            data: formData,

            success: function(mensagem) {
                $('#mensagem-cadastro').text('');
                $('#mensagem-cadastro').removeClass()
                if (mensagem.trim() == "Agendamento realizado com sucesso") {
                    $('#mensagem-cadastro').addClass('text-success')
                    $('#mensagem-cadastro').text('Carregando...')
                    window.alert('Agendamento realizado com sucesso');
                    window.location = 'avaliacao.php';


                } else {

                    $('#mensagem-cadastro').addClass('text-danger')
                    $('#mensagem-cadastro').text(mensagem)
                }


            },

            cache: false,
            contentType: false,
            processData: false,

        });

    });
</script>
<script type="text/javascript">
    function limpahora() {


        $("#horario").val('Selecione horario');


    }
</script>



</html>