<?php 
$servidor='localhost';
$banco= 'agendamento';
$usuario='root';
$senha='';


$sql= new PDO("mysql:dbname=$banco;host=$servidor;charset-utf8",$usuario,$senha);
try {
    
    # code...
} catch (\Throwable $e) {
echo    "erro ao conectar ao servidor:".$e;
}
?>