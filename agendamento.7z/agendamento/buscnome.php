<?php
if (isset($_POST['tel'])==0 ){ 
    exit;
 };

require_once('server.php');
$telefone=$_POST['tel'];
// $telefone='(14) 99644-0809';
$query=$sql->query("SELECT * from cliente where telefone_cliente = '$telefone'");
$result=$query->fetchAll(PDO::FETCH_ASSOC);
if (count($result)>0) {
echo $result[0]['nome_cliente'];
$id_cliente=$result[0]['id_cliente'];
}else{
    echo '';
};
if(@$id_cliente != ""){
    $agendamento=$sql->query("SELECT * from agenda where telefone_cliente = '$telefone' and ativo = 'a' order by id desc limit 1;");
    $agenda=$agendamento->fetchAll(PDO::FETCH_ASSOC);
    if (count($agenda)> 0) {
        @$dataagenda=$agenda[0]['dia'];
        $dataformatada=date("d/m/20y", strtotime($dataagenda));
        echo '*'.'Voce possui '.@$dataformatada;
        
    }
};





?>