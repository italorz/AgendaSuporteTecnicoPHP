<?php 
session_start();
require_once('server.php');
$cliente=$_POST['cliente'];
$telefone=$_POST['telefone'];
$avaliacao=$_POST['avaliacao'];
$query = $sql->prepare("INSERT INTO feedback (nome_cliente, telefone_cliente,avaliacao)
VALUES (:cliente, :telefone, :avaliacao)");
$query->bindValue(':cliente', $cliente);
$query->bindValue(':telefone', $telefone);
$query->bindValue(':avaliacao', $avaliacao);
$query->execute();
session_destroy();
echo

"<script>window.location='data.php'</script>";
?>
