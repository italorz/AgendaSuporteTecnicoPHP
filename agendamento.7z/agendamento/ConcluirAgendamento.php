<?php 

require_once('server.php');
session_start();
$AtvAtendimento='a';
$horario        =$_POST['horario'];
$idassunto      =intval($_POST['assunto']);
$observacoes    =$_POST['observacoes'];
$telefone       =$_POST['telefone'];
$cliente        =$_POST['cliente'];
$data           =$_POST['data'];
$IdTecnico      =intval($_POST['IdTecnico']);
$nome           =$_POST['nome'];
//recebe nome do assunto do agedamento
$qnomeassunto=$sql->query("SELECT * from assunto where id_assunto = $idassunto");
$rnomeassunto=$qnomeassunto->fetchAll(PDO::FETCH_ASSOC);
$nomeassunto=$rnomeassunto[0]['nome_assunto'];
$minuto=$rnomeassunto[0]['tempo'];
//verifica se o atendimento vai ocupar 1 ou 2 horarios e for 2 vai pegar o recebeu no metodo post e mostrar o proximo horario disponivel para registrar no mesmo dia
if ($minuto == '60') {
    $qreserva=$sql->query("SELECT * from horario where hora > '$horario' limit 1");
    $rreserva=$qreserva->fetchAll(PDO::FETCH_ASSOC);
    $reserva=$rreserva[0]['hora'];
};



//ve se tem algum horario marcado na mesma data e hora do form
$verifica=$sql->prepare("SELECT * from agenda where hora = ':hora' and data = ':data' and id_tecnico = ':idtec'");
$verifica->bindValue(':data',$data);
$verifica->bindValue(':hora',$horario);
$verifica->bindValue(':idtec',$IdTecnico);
$rverifica=$verifica->fetchAll(PDO::FETCH_ASSOC);
$cverifica=count($rverifica);
if ($cverifica>0) {
    echo 'escolha outra data';
    echo "<script>window.alert('Escolha outro horario')</script>";
    echo "<script>window.location='data.php'</script>";
} else{

    //insere o atedimento               
    $query = $sql->prepare("INSERT INTO agenda 
    (id_tecnico, dia, hora, nome_tecnico, id_assunto, nome_assunto, observacao, ativo, nome_cliente, telefone_cliente)
    VALUES 
    (:id_tecnico, :dia, :hora, :nome_tecnico, :id_assunto, :nome_assunto, :observacao, :ativo, :cliente, :telefone);");

$query->bindValue(':id_tecnico', $IdTecnico);
$query->bindValue(':dia', $data);
$query->bindValue(':hora', $horario);
$query->bindValue(':nome_tecnico', $nome);
$query->bindValue(':id_assunto', $idassunto);  
$query->bindValue(':nome_assunto', $nomeassunto);
$query->bindValue(':observacao', $observacoes);
$query->bindValue(':ativo', $AtvAtendimento);
$query->bindValue(':cliente', $cliente);
$query->bindValue(':telefone', $telefone);

$query->execute();
//salvo o ultimo id para atualizacoes futuras
$pai=$sql->lastInsertId();
if ($minuto == '60') {
    $qquery = $sql->prepare("INSERT INTO agenda 
    (id_tecnico, dia, hora, nome_tecnico, id_assunto, nome_assunto, observacao, ativo, nome_cliente, telefone_cliente, pai)
    VALUES 
    (:id_tecnico, :dia, :hora, :nome_tecnico, :id_assunto, :nome_assunto, :observacao, :ativo, :cliente, :telefone, :pai);");
    $qquery->bindValue(':id_tecnico', $IdTecnico);
    $qquery->bindValue(':dia', $data);
    $qquery->bindValue(':hora', $reserva);
    $qquery->bindValue(':nome_tecnico', $nome);
    $qquery->bindValue(':id_assunto', $idassunto);  
    $qquery->bindValue(':nome_assunto', $nomeassunto);
    $qquery->bindValue(':observacao', $observacoes);
    $qquery->bindValue(':ativo', 'x');
    $qquery->bindValue(':cliente', $cliente);
    $qquery->bindValue(':telefone', $telefone);
    $qquery->bindValue(':pai',$pai, PDO::PARAM_INT);
    
    $qquery->execute();  
}



if ($query) {
    echo 'Agendamento realizado com sucesso';
    $_SESSION['cliente']=$cliente;
    $_SESSION['telefone']=$telefone;
}else{
    echo"window.alert('Nao foi possivel ')";
}   
};






?>