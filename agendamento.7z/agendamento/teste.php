<?php 
require_once("server.php");
require_once("data.php");
require_once("horario.php");
$telefone = '(14) 99644-0809';
$IdTecnico = 1;
$data= '2024-01-07';
$hora= '08:30:00';


$query = $sql->prepare("SELECT * FROM agenda WHERE id_tecnico = :id_tecnico AND dia = :dia AND hora = :hora AND ativo = 'a'");
$query->bindValue(':id_tecnico', $id_tecnico);
$query->bindValue(':dia', $data);
$query->bindValue(':hora', $hora);
$query->execute();

$resultados = $query->fetchAll(PDO::FETCH_ASSOC);



// $queryAgenda = $sql->prepare("SELECT * FROM agenda WHERE id_tecnico IN (2, 3) AND dia = :dia");
// $queryAgenda->bindValue(':dia', $data);
// $queryAgenda->execute();
// $resultadosAgenda = $queryAgenda->fetchAll(PDO::FETCH_ASSOC);

echo '<pre>';
var_dump($resultados);
echo '</pre>';

// $nome = $sql->query("SELECT nome from tecnico where id_tecnico = $IdTecnico");
// $ResultadoNome = $nome->fetchAll(PDO::FETCH_ASSOC);

// $teste=count($ResultadoNome);
// if ($teste>0) {
//     echo"marior que 0";
// }


// $cadastrocliente=$sql->query("SELECT * from cliente where telefone_cliente = '$telefone'");
// $rcadcliente=$cadastrocliente->fetchAll(PDO::FETCH_ASSOC);
// $ccadcliente=count($rcadcliente);
// if ($ccadcliente>0) {
//     echo"marior que 0";
// }



?>