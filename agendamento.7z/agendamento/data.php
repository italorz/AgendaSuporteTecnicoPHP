<?php
$datahoje = date("d/m/20y");
require_once('server.php');
session_start();
$qtec = $sql->prepare("SELECT * from tecnico where ativa = 's' order by nome");
$qtec->execute();
$res = $qtec->fetchAll(PDO::FETCH_ASSOC);
$cont = count($res);
$delete = $sql->query("DELETE from feedback where avaliacao is null")
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <style>
        #formulario {
            padding-right: 15%;
            padding-left: 15%;
            padding-bottom: 3%;
        }

        @media screen and (max-width: 700px) {
            #formulario {
                padding-right: 0;
                padding-left: 0;
                padding-bottom: 0;
            }
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top shadow">
            <div class="container-fluid ">
                <a class="navbar-brand" href="restrito/restrito.php"><button type="button" class="btn btn-primary bg-dark" style="border-color:#212529; font-size: large;"><img src="img/1.png" alt="" style="height: 30px; width: 110px;"></button></a>


                <button class="navbar-toggler btn-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon btn-sm"></span>
                </button>
                <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel" style="transition: 1s;">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Usuario:</h5>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="transition: 1s;">
                                    Cadastro
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" style="transition: 1s;">
                                    <li><a class="dropdown-item" href="#">Usuario</a></li>
                                    <li><a class="dropdown-item" href="#">Servicos</a></li>
                                    <li><a class="dropdown-item" href="#">Categorias</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="container" style="padding-top: 75px;">

        <form method="post">
            <div class="shadow" id="formulario">
                <div class="form-group p-4">
                    <div class=".col-ms-6  m-2">
                        <small>Telefone:</small>
                        <!-- input telefone -->
                        <input type="tel" class="form-control" id="telefone" onchange="buscarNome()" name="telefone" required />
                    </div>
                    <div class=".col-ms-6  m-2">
                        <small>Nome:</small>
                        <!-- input nome -->
                        <input type="text" class="form-control" id="idnome" onclick="buscarNome()" name="cliente" required />
                    </div>

                    <div class=".col-ms-6  m-2">
                        <small>Selecione um Tecnico:</small><br>
                        <!-- input tecnico -->
                        <select class="form-control" id="tecnico" required name="tecnico" style="width: 100%; font-size: large;">
                            <option class="form-control" required name="tecnico" value=""></option>
                            <?php
                            if ($cont > 0) {
                                
                                    foreach ($res as $tec) {
                                    


                                    echo    '<option required class="form-control" name="tecnico" 
                                    value="' . $tec['id_tecnico'] . '">' . $tec['nome'] . '</option>';
                                };
                            } else {
                            };
                            ?>

                        </select>

                    </div>

                    <div class=".col-ms-6  m-2">
                        <small>Data:</small>
                        <input type="text" id="datepicker" class="form-control" value="'.<?php echo $datahoje ?>.'" name="data" placeholder="dd/mm/aaaa" required>







                    </div>

                    <div class="d-block .col-ms-6  m-2 text-center" id="horario">
                        <button type="submit" formaction="horario.php" class="btn btn-primary">Avançar</button>
                    </div>


        </form>

    </div>

</body>
<script>
    // Inicialize o flatpickr
    flatpickr("#datepicker", {
        dateFormat: 'd/m/Y', // Formato da data brasileiro
        minDate: 'today', // Bloquear datas anteriores à data atual
        locale: 'pt', // Configuração do idioma para português
    });
</script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
    function buscarNome() {
    var tel = $('#telefone').val();
    $.ajax({
        url: 'buscnome.php',
        method: 'POST',
        data: {tel},
        dataType: "text",
        success: function(result) {
            var corte = result.split("*");
            
            $("#idnome").val(corte[0]);
        }
    });
}

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>

<script>
        $(document).ready(function() {
            $('#telefone').mask('(00) 00000-0000');
            $('#cpf').mask('000.000.000-00');
            $('#cep').mask('00000-000');
            $('#cnpj').mask('00.000.000/0000-00');

        });
    </script>



</html>

<?php

?>