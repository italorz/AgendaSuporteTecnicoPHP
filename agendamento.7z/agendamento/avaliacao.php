<?php
$datahoje=date("d/m/20y");
require_once('server.php');
session_start();

@$cliente=$_SESSION['cliente'];
@$telefone=$_SESSION['telefone'];

if (isset($_SESSION['cliente'])==0) {
    echo  "<script>window.location='data.php'</script>";
  }

?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliacao</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Tn538Nl4zrL2UxWOdBqLwkHefIG5QDAHOBGLtn8i6T5br5r5zpf0tuw1u31PbbC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <style>
        #formulario {
            padding-right: 30%;
            padding-left: 30%;
            padding-bottom: 3%;
        }

        @media screen and (max-width: 700px) {
            #formulario {
                padding-right: 0;
                padding-left: 0;
                padding-bottom: 0;
            }
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top shadow">
            <div class="container-fluid ">
                <a class="navbar-brand" href="#"><button type="button" class="btn btn-primary bg-dark" style="border-color:#212529; font-size: large;"><img src="img/x.png" alt="" style="height: 30px; width: 110px;"></button></a>


              
                    
                </div>
            </div>
        </nav>
    </header>
    <div class="container" style="padding-top: 75px;">

        <form action="feedback.php" id="nota" method="post">
            <div class="shadow" id="formulario">
                <div class="form-group p-4">
                <label class="h6">Obrigado <?php echo $cliente;?> por usar nosso sistema de agendamento</label>


                    <div class=".col-ms-6  m-2">
                        <small>Atribua uma nota: (de 1 a 5)</small><br>
                        <select class="form-control text-center" id="avaliacao" name="avaliacao" required name="tecnico" style="width: 100%; font-size: large;">
                        <option required class="form-control" id="avaliacao"  value="n"></option>';
                        <option required class="form-control" id="avaliacao"  value="5">5</option>';
                        <option required class="form-control" id="avaliacao"  value="4">4</option>';    
                        <option required class="form-control" id="avaliacao"  value="3">3</option>';
                        <option required class="form-control" id="avaliacao"  value="2">2</option>';
                        <option required class="form-control" id="avaliacao"  value="1">1</option>';
                    </select>
                    <input type="hidden" name="cliente" value="<?php echo $cliente;?>">
                    <input type="hidden" name="telefone" value="<?php echo $telefone;?>">
                    </div>
                    <div class=".col-ms-6 text-center  m-2">
                    <div class="d-flex"></div>
                    <a href="data.php" class="btn btn-link m-2" style="color: grey;">Voltar</a>
                    <button type="submit" id="avaliar" class="btn btn-primary m-2">Avaliar</button>
                    </div>
                    </div>

                    
                   




                </div>

                


        </form>

    </div>

</body>
<script>
    $(document).ready(function(){
        $('#nota').submit(function(){

            var snota = $('#avaliacao').val();

            if (snota=='n') {
                window.alert('para avaliar atribua uma nota');
                
            } else {
                
            }
        })
    })
</script>


</html>

