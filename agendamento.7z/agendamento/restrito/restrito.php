<?php
require_once('../server.php');
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuario</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <style>
        #formulario {
            padding-right: 30%;
            padding-left: 30%;
            padding-bottom: 3%;
        }

        @media screen and (max-width: 700px) {
            #formulario {
                padding-right: 0;
                padding-left: 0;
                padding-bottom: 0;
            }
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top shadow">
            <div class="container-fluid ">
                <a class="navbar-brand" href="#"><button type="button" class="btn btn-primary bg-dark" style="border-color:#212529; font-size: large;"><img src="1.png" alt="" style="height: 30px; width: 110px;"></button></a>

            </div>
        </nav>
    </header>
    <div class="container" style="padding-top: 75px;">

        <form action="crestrito.php" id="restrito" method="post">
            <div class="shadow" id="formulario">
                <div class="form-group p-4">


                    <div class="m-2">
                        <small>Email</small><br>
                        <input type="text" class="form-control" id="emailtec" name="emailtec" required />
                    </div>
                    <div class="m-2">
                        <small>Senha</small><br>
                        <div class="d-flex">
                            <input type="password" class="form-control" id="senhaltec" name="senhatec" required />
                            <button type="button" class="btn btn-primary btn-sm ms-1" onclick="mostrasenha()">ver</button>
                        </div>
                    </div>
                    <div class="m-2">
                        <div class="text-center" style="margin-left: 8%;">



                            <button type="submit" id="avaliar" class="btn btn-primary m-2">Login</button>
                            <a href="data.php" class="btn btn-link m-2" style="color: grey;">Recuperar senha</a>
                        </div>
                    </div>
                </div>







            </div>




        </form>

    </div>

</body>
<script>
    function mostrasenha() {
        var senha = $("#senhaltec").attr("type")

        if (senha === "password") {
            senha = "text";
        } else {
            senha = "password";
        }
        $("#senhaltec").attr("type", senha);
    }
</script>


</html>