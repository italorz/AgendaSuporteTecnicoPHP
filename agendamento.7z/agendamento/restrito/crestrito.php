<?php 
require_once('../server.php');
session_start();
$email=$_POST['emailtec'];
$senha=$_POST['senhatec'];

$query=$sql->prepare('SELECT * from tecnico where email_tecnico = :email and senha_tecnico = :senha;');
$query->bindValue(':email',$email,PDO::PARAM_STR);
$query->bindValue(':senha',$senha,PDO::PARAM_STR);
$query->execute();
$resultado=$query->fetch(PDO::FETCH_ASSOC);
$count=count($resultado);
if($count> 0){
    // echo'<pre>';
    // var_dump($resultado);
    // echo'</pre>';
    $_SESSION['idtecnico']=$resultado['id_tecnico'];
    $_SESSION['nometecnico']=$resultado['nome'];
    $_SESSION['emailtecnico']=$resultado['email_tecnico'];
    $_SESSION['senhatecnico']=$resultado['senha_tecnico'];
    
    echo "<script>window.location='tabela.php'</script>";
    
}
else{

};


?>