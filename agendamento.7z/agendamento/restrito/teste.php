<?php
require_once('../server.php');
session_start();
$idtec = $_SESSION['idtecnico'];

if ($idtec == 0) {
    echo "<script>window.location='restrito.php'</script>";
};

$query = $sql->query("SELECT * from agenda where id_tecnico = $idtec and ativo = 'a' order by dia, hora");
$row = $query->fetchall(PDO::FETCH_ASSOC);
$count = count($row);
if ($count == 0) {
    echo '<script>windows.alert("Esse Tecnico nao possui nenhum tipo de agendmento")</script>';
} else {
    
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modalmanager.min.js"></script>
   
</head>

<body>


    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top shadow">
            <div class="container-fluid ">
                <a class="navbar-brand" href="#"><button type="button" class="btn btn-primary bg-dark" style="border-color:#212529; font-size: large;"><img src="1.png" alt="" style="height: 30px; width: 110px;"></button></a>


                <button class="navbar-toggler btn-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon btn-sm"></span>
                </button>
                <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel" style="transition: 1s;">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Usuario: <?php echo $_SESSION['nometecnico'];?></h5>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="transition: 1s;">
                                    Cadastro
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" style="transition: 1s;">
                                    <li><a class="dropdown-item" href="#">Usuario</a></li>
                                    <li><a class="dropdown-item" href="#">Servicos</a></li>
                                    <li><a class="dropdown-item" href="#">Categorias</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    
    <div class="container" style="padding-top: 75px;">
    <a type="button" class="btn btn-outline-secondary btn-sm shadow" href = "../data.php">Agendar</a>
    
            <div class="shadow" id="formulario">
                <div class="p-4">
                    <div class="d-flex .col-ms-6  m-2">

                    


<?php
echo <<<HTML
 <table class="table table-hover">
  <thead class="m-4">
    <tr class="m-4">
      <th scope="col">#</th>
      <th scope="col">data</th>
      <th scope="col">hora</th>
      <th scope="col">nome</th>
      <th scope="col" id="mobile">atendimento</th>
      <th scope="col" id="mobile">fone</th>
    </tr>
  </thead>
  <tbody>
  
HTML;
                        for ($i = 0; $i < $count; $i++) {
                            foreach ($row[$i] as $key => $value) {
                            }
                            $id_agenda = $row[$i]['id'];
                            $dia = $row[$i]['dia'];
                            $data=date("d/m/y",strtotime($dia));
                            $hora = $row[$i]['hora'];
                            $nome = $row[$i]['nome_cliente'];
                            $atendimento = $row[$i]['nome_assunto'];
                            $obs=$row[$i]['observacao'];
                            $telefone=$row[$i]['telefone_cliente'];

                        
echo <<<HTML
<tr>
<th scope="row"><a class="btn-outline-secondary btn-sm" onclick="edit('{$id_agenda}','{$dia}','{$data}','{$hora}','{$nome}','{$atendimento}','{$obs}','{$telefone}')"><i class="bi bi-pencil-square"></i></a>
</th>
      <td>{$data}</td>
      <td>{$hora}</td>
      <td>{$nome}</td>
      <td id="mobile">{$atendimento}</td>
      <td id="mobile">{$telefone}</td>
HTML;
};
echo <<<HTML
</tr>
  </tbody>
</table>
HTML;

                        ?>

                    </div>
                </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>

<script>
    function edit(id_agenda,dia,data,hora,nome,atendimento,obs,telefone){
       $("#flipFlop").modal("show");
    };
</script>

</html>



<?php 


?>

<!-- The modal -->
<div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
<h4 class="modal-title" id="modalLabel">Modal Title</h4>
</div>
<div class="modal-body">
Modal content...
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>


